/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2022 Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2022 Yue Li <yueli@nju.edu.cn>
 *
 * This file is part of Tai-e.
 *
 * Tai-e is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Tai-e is distributed in the hope that it will be useful,but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
 * Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Tai-e. If not, see <https://www.gnu.org/licenses/>.
 */

package pascal.taie.analysis.dataflow.analysis.constprop;

import pascal.taie.analysis.dataflow.analysis.AbstractDataflowAnalysis;
import pascal.taie.analysis.graph.cfg.CFG;
import pascal.taie.config.AnalysisConfig;
import pascal.taie.ir.IR;
import pascal.taie.ir.exp.ArithmeticExp;
import pascal.taie.ir.exp.BinaryExp;
import pascal.taie.ir.exp.BitwiseExp;
import pascal.taie.ir.exp.ConditionExp;
import pascal.taie.ir.exp.Exp;
import pascal.taie.ir.exp.IntLiteral;
import pascal.taie.ir.exp.ShiftExp;
import pascal.taie.ir.exp.Var;
import pascal.taie.ir.stmt.DefinitionStmt;
import pascal.taie.ir.stmt.Stmt;
import pascal.taie.language.type.PrimitiveType;
import pascal.taie.language.type.Type;
import pascal.taie.util.AnalysisException;

public class ConstantPropagation extends
        AbstractDataflowAnalysis<Stmt, CPFact> {

    public static final String ID = "constprop";

    public ConstantPropagation(AnalysisConfig config) {
        super(config);
    }

    @Override
    public boolean isForward() {
        return true;
    }

    @Override
    public CPFact newBoundaryFact(CFG<Stmt> cfg) {
        CPFact fact = newInitialFact();
        for (Var param : cfg.getIR().getParams()) {
            if (canHoldInt(param)) {
                fact.update(param, Value.getNAC());
            }
        }
        return fact;
    }

    @Override
    public CPFact newInitialFact() {
        return new CPFact();
    }

    @Override
    public void meetInto(CPFact fact, CPFact target) {
        for (Var var : fact.keySet()) {
            Value v1 = target.get(var);
            Value v2 = fact.get(var);
            target.update(var, meetValue(v1, v2));
        }
    }

    /**
     * Meets two Values.
     */
    public Value meetValue(Value v1, Value v2) {
        if (v1.isUndef()) {
            return v2;
        }
        if (v2.isUndef()) {
            return v1;
        }
        if (v1.isNAC() || v2.isNAC()) {
            return Value.getNAC();
        }
        // both are constants
        if (v1.getConstant() == v2.getConstant()) {
            return v1;
        } else {
            return Value.getNAC();
        }
    }

    @Override
    public boolean transferNode(Stmt stmt, CPFact in, CPFact out) {
        CPFact oldOut = out.copy();
        out.clear();
        out.copyFrom(in);
        if (stmt instanceof DefinitionStmt defStmt
                && defStmt.getLValue() instanceof Var lhs
                && canHoldInt(lhs)) {
            Value val = evaluate(defStmt.getRValue(), in);
            out.update(lhs, val);
        }
        return !out.equals(oldOut);
    }

    /**
     * @return true if the given variable can hold integer value, otherwise false.
     */
    public static boolean canHoldInt(Var var) {
        Type type = var.getType();
        if (type instanceof PrimitiveType) {
            switch ((PrimitiveType) type) {
                case BYTE:
                case SHORT:
                case INT:
                case CHAR:
                case BOOLEAN:
                    return true;
            }
        }
        return false;
    }

    /**
     * Evaluates the {@link Value} of given expression.
     *
     * @param exp the expression to be evaluated
     * @param in  IN fact of the statement
     * @return the resulting {@link Value}
     */
    public static Value evaluate(Exp exp, CPFact in) {
        if (exp instanceof IntLiteral intLiteral) {
            return Value.makeConstant(intLiteral.getValue());
        } else if (exp instanceof Var var) {
            return in.get(var);
        } else if (exp instanceof BinaryExp binaryExp) {
            Value v1 = evaluate(binaryExp.getOperand1(), in);
            Value v2 = evaluate(binaryExp.getOperand2(), in);
            if (v1.isUndef() || v2.isUndef()) {
                return Value.getUndef();
            }
            if (v1.isNAC() || v2.isNAC()) {
                return Value.getNAC();
            }
            int a = v1.getConstant();
            int b = v2.getConstant();
            if (exp instanceof ArithmeticExp arithmetic) {
                return switch (arithmetic.getOperator()) {
                    case ADD -> Value.makeConstant(a + b);
                    case SUB -> Value.makeConstant(a - b);
                    case MUL -> Value.makeConstant(a * b);
                    case DIV -> (b == 0) ? Value.getNAC() : Value.makeConstant(a / b);
                    case REM -> (b == 0) ? Value.getNAC() : Value.makeConstant(a % b);
                };
            } else if (exp instanceof ConditionExp condition) {
                return switch (condition.getOperator()) {
                    case EQ -> Value.makeConstant(a == b ? 1 : 0);
                    case NE -> Value.makeConstant(a != b ? 1 : 0);
                    case LT -> Value.makeConstant(a < b ? 1 : 0);
                    case GT -> Value.makeConstant(a > b ? 1 : 0);
                    case LE -> Value.makeConstant(a <= b ? 1 : 0);
                    case GE -> Value.makeConstant(a >= b ? 1 : 0);
                };
            } else if (exp instanceof ShiftExp shift) {
                return switch (shift.getOperator()) {
                    case SHL -> Value.makeConstant(a << b);
                    case SHR -> Value.makeConstant(a >> b);
                    case USHR -> Value.makeConstant(a >>> b);
                };
            } else if (exp instanceof BitwiseExp bitwise) {
                return switch (bitwise.getOperator()) {
                    case OR -> Value.makeConstant(a | b);
                    case AND -> Value.makeConstant(a & b);
                    case XOR -> Value.makeConstant(a ^ b);
                };
            }
        }
        return Value.getNAC();
    }
}
